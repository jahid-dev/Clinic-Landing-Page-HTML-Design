$(document).ready(function(){
  $('.counter').counterUp({
        delay: 10,
        time: 1000
    });

  $('.slider').owlCarousel({
    loop:true,
    margin:10,
    autoplay: true,
    autoplayTimeout: 6000,
    smartSpeed: 500,
    animateOut: 'fadeOut',
    dots: false,
    animateIn: 'fadeIn',
    nav: true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});
  
  $('.testimonial').owlCarousel({
    loop:true,
    margin:0,
    nav:false,
    autoplay: true,
    autoplayTimeout: 5000,
    smartSpeed: 500,
    dots:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});
 
  $('.gallery').owlCarousel({
    loop:true,
    margin:0,
    nav:true,
    autoplay: false,
    autoplayTimeout: 5000,
    smartSpeed: 500,
    dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:4
        }
    }
});

  $('.single-gallery-overley > a').magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        mainClass: 'mfp-img-mobile',
        image: {
            verticalFit: true
        }
        
    });

  $('body').scrollspy({target: ".navbar", offset: 80});   
      $(".menu a, .down-btn a").on('click', function(event) {
        if (this.hash !== "") {
          event.preventDefault();
          var hash = this.hash;

          $('html, body').animate({
            scrollTop: $(hash).offset().top
          }, 1000, function(){
           
          });
        }  
      });

    $(window).on('load', function(){
        $('#preloder').delay(200).fadeOut(2000);
        $('.sk-three-bounce').fadeOut(1000);
    });
    new WOW().init();

    $('.scrollup').on('click', function(e){
        $('html').animate({
            'scrollTop':0
        },1000);
        return false;
    });
    $(window).scroll(function(){
        var halcyan = $(window).scrollTop();
        if(halcyan>400){
            $('.scrollup').slideDown(1000);
        }
        else{
            $('.scrollup').slideUp(1000);
        }

    });


});